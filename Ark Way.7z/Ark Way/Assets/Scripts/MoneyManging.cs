﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MoneyManging : MonoBehaviour {


    public Text MoneyText;
    public int currentAmount;




	// Use this for initialization
	void Start ()
    {

        if (PlayerPrefs.HasKey("CurrentGold"))
        {
            currentAmount = PlayerPrefs.GetInt("CurrentGold");
        } else
        {
            currentAmount = 0;
            PlayerPrefs.SetInt("CurrentGold", 0);
        }

        MoneyText.text = "Gold" + currentAmount;

    }
	
	// Update is called once per frame
	void Update ()
    {
		
	}



    public void AddMoney(int GoldToAdd)
    {
        currentAmount += GoldToAdd;
        PlayerPrefs.SetInt("CurrentGold", currentAmount);
        MoneyText.text = "Gold" + currentAmount;
    }


}