﻿using UnityEngine;
using System.Collections;


public class LevelLoader : MonoBehaviour
{
    public bool PlayerWithinZone;

    public string LevelToLoad;

    public string LevelTag;

	void Start() 
	{
        PlayerWithinZone = false;
	}

    void update()
    {
        if (Input.GetAxisRaw("Vertical") > 0 && PlayerWithinZone)
        {
            LoadLevel();
        }
    }

    public void LoadLevel()
    {
        PlayerPrefs.SetInt(LevelTag, 1);
        
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.name == "Player")
        {
            PlayerWithinZone = true;
        }
    }
}
