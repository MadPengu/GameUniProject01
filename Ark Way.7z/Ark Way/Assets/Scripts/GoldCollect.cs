﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoldCollect : MonoBehaviour {

    public int Value;
    public MoneyManging TheMM;

	// Use this for initialization
	void Start ()
    {

        TheMM = FindObjectOfType<MoneyManging>();

	}
	
	// Update is called once per frame
	void Update () 
    {
		

	}

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (gameObject.name == "Player")
        {
            TheMM.AddMoney(Value);
            Destroy(gameObject);
        }
    }


}
